@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.mycom.com/movie")
package com.mycom.movie;

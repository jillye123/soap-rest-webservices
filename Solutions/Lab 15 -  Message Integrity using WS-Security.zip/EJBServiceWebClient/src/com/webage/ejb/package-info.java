@javax.xml.bind.annotation.XmlSchema(namespace = "http://ejb.webage.com/")
package com.webage.ejb;

package com.webage.ejb.view;

import com.webage.beans.Soup;

public interface OrderSoupRemote {

	String orderSoup(Soup soup);

}
